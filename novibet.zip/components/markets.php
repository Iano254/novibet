<div class="market-header" style="padding: 10px; background-color: #303540; display: flex; justify-content: space-between;">
    <span class="market-header-title" style="color:white; font-weight: bold;">English Premiere League | Today</span>
    <button style=" color:black; border-color:transparent; border-width: 0px; font-size: 12px; background-color: white;" class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Today Games
                </button>
                <div class="dropdown-menu shadow-md" aria-labelledby="dropdownMenuButton" style="padding:0px;">
                    <a class="dropdown-item" href="#" style="font-size:10px;">Action</a>
                    <a class="dropdown-item" href="#" style="font-size:10px;">Another action</a>
                    <a class="dropdown-item" href="#" style="font-size:10px;">Something else here</a>
                </div>
    
</div>
<div class="markets-body" style="background-color: white; padding: 10px;">
    <div class="row">
        <div class="col-md-3">
            
        </div>
        <div class="col-md-3" style="text-align: center; display: flex; justify-content: space-evenly;">
            <button class="btn btn-secondary smallen-head" style="color:#303540;">1</button>
            <button class="btn btn-secondary smallen-head" style="color:#303540;">X</button>
            <button class="btn btn-secondary smallen-head" style="color:#303540;">2</button>
            
        </div>
        <div class="col-md-3 hide-mobi" style="text-align: center; display: flex; justify-content: space-evenly;">
            <button class="btn btn-secondary smallen-head" style="color:#303540;">1ORX</button>
            <button class="btn btn-secondary smallen-head" style="color:#303540;">XOR2</button>
            <button class="btn btn-secondary smallen-head" style="color:#303540;">1OR2</button>
        </div>
        <div class="col-md-3 hide-mobi" style="text-align: center; display: flex; justify-content: space-evenly;">
            <button class="btn btn-secondary smallen-head" style="color:#303540;"> NG</button>
            <button class="btn btn-secondary smallen-head" style="color:#303540;">GG </button>
            <button class="btn btn-secondary smallen-head" style="color:#303540;">M +</button>
        </div>
    </div>

    <div class="odd-wrapper shadow-sm" style="padding-right: 0px;">
        <h6 style="font-size:12px;"><span class="fa fa-bar-chart "></span> <span class="fa fa-clock-o "></span> 4th Jan 20:30</h6>
        <div class="row">
        <div class="col-md-3">
            <div style="padding: 5px;">
                <h5 style="font-size:12px;">Manchester Utd Vs Manchester Cty</h5>

            </div>
            
        </div>
        <div class="col-md-3" style="text-align: center; display: flex; justify-content: space-evenly;">
            <button class="btn btn-secondary odd-selector" style="color:#303540;">1.35</button>
            <button class="btn btn-secondary odd-selector" style="color:#303540;">2.44</button>
            <button class="btn btn-secondary odd-selector" style="color:#303540;">5.66</button>
            
        </div>
        <div class="col-md-3 hide-mobi" style="text-align: center; display: flex; justify-content: space-evenly;">
            <button class="btn btn-secondary odd-selector" style="color:#303540;">5.66</button>
            <button class="btn btn-secondary odd-selector" style="color:#303540;">5.66</button>
            <button class="btn btn-secondary odd-selector" style="color:#303540;">5.66</button>
        </div>
        <div class="col-md-3 hide-mobi" style="text-align: center; display: flex; justify-content: space-evenly;">
            <button class="btn btn-secondary odd-selector" style="color:#303540;">5.66</button>
            <button class="btn btn-secondary odd-selector" style="color:#303540;">5.66</button>
            <button class="btn btn-secondary odd-selector" style="color:#303540;">30+</button>
        </div>
    </div>
    </div>

    <div class="odd-wrapper shadow-sm" style="padding-right: 0px;">
        <h6 style="font-size:12px;"><span class="fa fa-bar-chart "></span> <span class="fa fa-clock-o "></span> 4th Jan 20:30</h6>
        <div class="row">
        <div class="col-md-3">
            <div style="padding: 5px;">
                <h5 style="font-size:12px;">Manchester Utd Vs Manchester Cty</h5>
                
            </div>
            
        </div>
        <div class="col-md-3" style="text-align: center; display: flex; justify-content: space-evenly;">
            <button class="btn btn-secondary odd-selector" style="color:#303540;">1.35</button>
            <button class="btn btn-secondary odd-selector" style="color:#303540;">2.44</button>
            <button class="btn btn-secondary odd-selector" style="color:#303540;">5.66</button>
            
        </div>
        <div class="col-md-3 hide-mobi" style="text-align: center; display: flex; justify-content: space-evenly;">
            <button class="btn btn-secondary odd-selector" style="color:#303540;">5.66</button>
            <button class="btn btn-secondary odd-selector" style="color:#303540;">5.66</button>
            <button class="btn btn-secondary odd-selector" style="color:#303540;">5.66</button>
        </div>
        <div class="col-md-3 hide-mobi" style="text-align: center; display: flex; justify-content: space-evenly;">
            <button class="btn btn-secondary odd-selector" style="color:#303540;">5.66</button>
            <button class="btn btn-secondary odd-selector" style="color:#303540;">5.66</button>
            <button class="btn btn-secondary odd-selector" style="color:#303540;">30+</button>
        </div>
    </div>
    </div>
</div>