<div id="top-head">
	<div id="logo-section" style="display: flex">
		<img id="logo" src="img/novibet-white.svg" style=" ">
		<div class="item-wrapper hide-mobi" style="padding-top: 15px; ">
		<a href="/" class="top-nav-list-item">SPORTS</a>
		</div>
	</div>
	<div id="login-section">
		<button class="btn btn-secondary login-btn" data-toggle="modal" data-target="#loginModal">LOGIN</button>
		<button class="btn btn-secondary reg-btn"  data-toggle="modal" data-target="#regModal">REGISTER</button>
	</div>
</div>

<div id="top-head-2">
	<div id="logo-section" style="display: flex">
		<form class="hide-mobi">
			<input style="font-size:10px;" type="text" class="form-control" id="validationTooltip01" placeholder="First name" value="Mark" required>
		</form>
		<ul class="nav">
		  <li class="nav-item">
		    <a class="nav-link active" href="#">DAILY COUPON</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" href="#">LIVE SCHEDULES</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" href="#">PROMOTIONS</a>
		  </li>
		  
		</ul>
		
	</div>
	<div id="login-section">
		<ul class="nav nav2">
		  
		  <li class="nav-item">
		    <a class="nav-link" href="#">ENGLISH</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" href="#"><span class="fa fa-clock-o "></span> 21:00</a>
		  </li>
		  
		</ul>
	</div>
</div>