<div class="modal fade" id="regModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      
      <div class="modal-body login-modal" style="padding:30px">
       <form>
		  <div class="form-group">
		    <label for="exampleInputEmail1">Phone</label>
		    <input type="phone" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="07xxx" style="height:auto; padding-top:10px!important; padding-bottom: 10px!important">
		    
		  </div>
		  <div class="form-group">
		    <label for="exampleInputPassword1">Password</label>
		    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" style="height:auto; padding-top:10px!important; padding-bottom: 10px!important">
		  </div>

		  <div class="form-group">
		    <label for="exampleInputPassword1">Confirm Password</label>
		    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" style="height:auto; padding-top:10px!important; padding-bottom: 10px!important">
		  </div>
		  
		  <button type="submit" class="btn btn-primary " style="width: 100%; background-color: #4B5160; border: 0px; padding-top:15px; padding-bottom: 15px ">REGISTER</button>
		</form>
      </div>
      
    </div>
  </div>
</div>